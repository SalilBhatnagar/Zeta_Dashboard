export default function DoctorWorkbench_ListProduct() {
    return <>
    <div className="div-dashbord">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                    <h1 className="h1-dashHeading">
                      Doctor Workbench List Product
                    </h1>
                    </div>
                </div>
            </div>
        </div>
        <hr/>
    </>
}