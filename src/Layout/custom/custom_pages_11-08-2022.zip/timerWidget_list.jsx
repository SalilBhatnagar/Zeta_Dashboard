export default function TimerWidgetList() {
    return <>
    <div className="div-dashbord">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                <h1 className="h1-dashHeading">
                   Timer Widget List
                </h1>
                </div>
            </div>
        </div>
     </div>
     <hr/>
    </>
}