export default function HeroBanner() {
    return <>
      <div className="div-dashbord">
      <div class="container">
        <div class="row">
            <div class="col-md-12">
              <h1 className="h1-dashHeading">
                 HeroBanner
               </h1>
            </div>
        </div>
        </div>
     </div>
     <hr/>
    </>
}